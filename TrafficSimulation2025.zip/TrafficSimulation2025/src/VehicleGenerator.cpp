#include "VehicleGenerator.h"

VehicleGenerator::VehicleGenerator() {
    // default
    frequency = 10;
    last_generated = 0;
}
